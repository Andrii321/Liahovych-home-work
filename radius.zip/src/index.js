
const r = Math.floor(Math.random() * (100 - 10) + 10);
const PI = 3.14;
const s = r * r * PI;
const l = 2 * PI * r;

console.log(r);
console.log(s);
console.log(l);
