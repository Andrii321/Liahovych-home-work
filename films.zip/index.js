const film = {
  name: "Terminator-2. JudgementDay",
  year: "1991",
  genre: "action",
  casherfish: "520$",
  budget: "100$",
  director: "James Cameron",
  rating: "8,5 IMDb",
  actors:
    "Arnold Schwarzenegger, Linda Hamilton, Robert Patrick, Edward Furlong"
};
console.log(Object.keys(film));
console.log(film.name);
console.log(film.year);
console.log(film.genre);
console.log(film.casherfish);
console.log(film.budget);
console.log(film.director);
console.log(film.rating);
console.log(film.actors);
